function inrect(x,y,rx,ry,rw,rh) {
	return x>=rx && x<=rx+rw && y>=ry && y<=ry+rh;
}
